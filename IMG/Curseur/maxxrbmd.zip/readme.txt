﻿=== Maxx Red and Black MD Cursor Set ===

By: ツ Mimi Destino ♡ (http://www.rw-designer.com/user/38152) mlopez166@hotmail.com

Download: http://www.rw-designer.com/cursor-set/maxxrbmd

Author's description:

  
 
 ツ MIMI DESTINO ♥.♡ 

Enjoy the set.
Thanks for download and review ✫✫✫✫✫

--

Blue: http://www.rw-designer.com/cursor-set/maxxbluemd

red and transparent: http://www.rw-designer.com/cursor-set/maxx-red-mimi-destino

--

How to install?

without voice
https://youtu.be/-F9ku2X63_g

How to get cute mouse cursors │FREE│  
https://youtu.be/LaPcuFN_WF8

see this video with voice
https://youtu.be/VOr3HZHS4fQ

---

Como instalarlos?
https://youtu.be/EGx6plXI0Yc

--

Have any cursor requests? feel free to comment here -->  http://www.rw-designer.com/entry/3308

social networks --> http://www.rw-designer.com/entry/3309

my favorite cursors set --> http://www.rw-designer.com/cursor-set/donutskawaiimd

AND THIS -- http://www.rw-designer.com/cursor-set/bunniesandstrawberriesmd

Discord:  https://discord.gg/xATjrHDPm5

CREDITS: http://www.rw-designer.com/cursor-set/maxx-red-mimi-destino

= Are you going to enter a set of cursors or icons in this month's theme contest? =

http://www.rw-designer.com/forum/6239

 
 

     

==========

License: Creative Commons - Attribution + Noncommercial

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
* Noncommercial - You may not use this work for commercial purposes.